package mart.constants;

public class Constants {
	
	public static final String URL = "jdbc:mysql://localhost:3306/control?useSSL=false&&allowPublicKeyRetrieval=true";
	public static final String DRIVER = "com.mysql.jdbc.Driver";
	public static final String USER = "root";
	public static final String PASSWORD = "";

}
